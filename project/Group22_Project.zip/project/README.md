Final Project

This project simulates different agents of each specie type meeting and interacting through their "personalities" which, in turn, affects their "mood". It uses FIPA communication protocol. Additionally, an overall average global mood is observed for the simulation. The `Project_Report.pdf` goes over the implementation and experimentation details.

This was done as part of the final project for ID2209 - Distributed Artificial Intelligence and Intelligent Agents at KTH Royal Institute of Technology.